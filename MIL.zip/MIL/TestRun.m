% run the setup file to set the matlab paths and add the relevant folders
% to matlab path ...
% Load config sets, global constants, and associated workspace variables
clear all
%current_folder_path = pwd;
start_setup = strcat(pwd,'\Simulink\SimulinkCommon\start_taxibot_main.m');
run(start_setup);

% get the model under test
[modelname_in, modelpath_in] = uigetfile('*.mdl', 'Select model under test');
model_ref = [modelpath_in modelname_in];
model_name_split = regexp(modelname_in, '\.', 'split');
model_name = char(model_name_split(1));
open_system(model_name);
trig_blk = find_system(model_name, 'BlockType', 'TriggerPort');
trigblkH = get_param(trig_blk, 'handle');

% memorize parameters settings for trig block to restore the same later.

% for trignum = 1:length(trig_blk)
%     trigblk_params = get_param(trig_blk(1), 'DialogParameters');
%     for k=1:length(trigblk_params)
%         trigblk_fldnames = fieldnames(trigblk_params{k});
%         trigblk_fldnames = trigblk_fldnames'; 
%         indx = 1;
%         for j=1:length(trigblk_fldnames)
%             param_array(trignum, indx) = trigblk_fldnames(j);
%             param_array(trignum, indx+1) = get_param(trig_blk, char(trigblk_fldnames(j)));
%             indx = indx+2;
%         end
%     end
% end

% while running for whole system, this needs to be commented. 
% delete_block(trig_blk);
% save_system(model_name);

% create test harness for the model under test along with expected outputs
% signals part of the signal builder
[obj] = makeharness_compareresults(model_name);

% simulate the test harness - test data fed into model under test and
% output signals logged
obj.runSimAll;

% Generate simulink report for the test harness
% this requires Simulink Report Generator license
% obj.runReport;

% to add the removed trigger block
% for n = 1:length(trig_blk)
%     dst = char(trig_blk(n));
%     addedblk = add_block('built-in/TriggerPort',dst);
% end
% paramN=length(param_array)/2;
% arr_str = '';
% for prop = 1:paramN
%     blk_attrib = char(param_array(2*prop-1));
%     attrib_val = char(param_array(2*prop));
%     arr_str=strcat(blk_attrib,',',attrib_val);
% end
%     set_param(addedblk, sprintf('%s',arr_str),'');
% 
% save_system(model_name);